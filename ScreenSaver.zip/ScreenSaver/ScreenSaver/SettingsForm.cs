﻿/*
 * SettingsForm.cs
 * By Frank McCown
 * Summer 2010
 * 
 * Feel free to modify this code.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Security.Permissions;

namespace ScreenSaver
{
    public partial class SettingsForm : Form
    {
        public SettingsForm()
        {
            InitializeComponent();
            LoadSettings();
            Program.LoadSettingsAppPath();
            textBox1.Text = Program.app_start_path;
        }

        /// <summary>
        /// Load display text from the Registry
        /// </summary>
        private void LoadSettings()
        {
            RegistryKey key = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Demo_ScreenSaver_1");
            if (key == null)
                textBox.Text = "C# Screen Saver";
            else
                textBox.Text = (string)key.GetValue("text");
        }

        /// <summary>
        /// Save text into the Registry.
        /// </summary>
        private void SaveSettings()
        {
            // Create or get existing subkey
            RegistryKey key1 = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Demo_ScreenSaver_1");
            RegistryKey key2 = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Demo_ScreenSaver_2");

            key1.SetValue("text", textBox.Text);
            key2.SetValue("text", textBox1.Text);
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            SaveSettings();
            Close();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Browse

            var filePath = string.Empty;

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = "c:\\";
                openFileDialog.Filter = "exe files (*.exe)|*.exe|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    //Get the path of specified file
                    filePath = openFileDialog.FileName;

                }
            }

            textBox1.Text = filePath;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // test execution
            bool is_running = false;

            if (Program.proc != null)
            {
                is_running = Program.IsRunning(Program.proc);
            }

            string app_to_start;
            app_to_start = textBox1.Text;

            if (!is_running)
            {
                if (app_to_start != "")
                {
                    try
                    {
                        Program.StartWrapper(app_to_start);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error opening file \"" + app_to_start + "\"");
                    }
                }
            }
            else
            {
                MessageBox.Show("Process is already running.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool is_running;

            if (Program.proc != null)
            {
                is_running = Program.IsRunning(Program.proc);

                //MessageBox.Show(is_running.ToString());
                if (is_running)
                {
                    Program.KillProcessAndChildren(Program.proc.Id);
                }
                else
                {
                    MessageBox.Show("No process running");
                }
            }
            else
            {
                MessageBox.Show("No process started");
            }
        }


    }
}
